# Bu satırları mevcut products/models.py dosyasının SONUNA ekle

class BkuUrun(models.Model):
    """BKU (Bitki Koruma Ürünleri) veritabanından çekilen ürünler."""

    bitki           = models.CharField(max_length=255, verbose_name="Bitki")
    aktif_madde     = models.CharField(max_length=255, blank=True, default='', verbose_name="Aktif Madde")
    ruhsat_no       = models.CharField(max_length=100, blank=True, default='', verbose_name="Ruhsat No")
    urun_adi        = models.CharField(max_length=255, verbose_name="Ürün Adı")
    etken_madde     = models.CharField(max_length=255, blank=True, default='', verbose_name="Etken Madde")
    firma           = models.CharField(max_length=255, blank=True, default='', verbose_name="Firma")
    doz             = models.CharField(max_length=255, blank=True, default='', verbose_name="Doz")
    zarali          = models.CharField(max_length=255, blank=True, default='', verbose_name="Zararlı")
    son_ilac_hasat  = models.CharField(max_length=100, blank=True, default='', verbose_name="Son İlaç-Hasat (gün)")
    created_at      = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "BKU Ürün"
        verbose_name_plural = "BKU Ürünler"
        ordering = ['bitki', 'urun_adi']
        unique_together = ('ruhsat_no', 'bitki', 'zarali')  # duplicate engelle

    def __str__(self):
        return f"{self.urun_adi} — {self.bitki}"
